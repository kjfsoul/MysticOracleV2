import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  const { goal = '' } = req.query;
  const targetPath = process.cwd();

  function crawlDirectory(dir, patterns = ['-fixed', '-updated', 'legacy']) {
    const matches = [];
    function walk(current) {
      fs.readdirSync(current).forEach(file => {
        const fullPath = path.join(current, file);
        if (fs.statSync(fullPath).isDirectory()) return walk(fullPath);
        const match = patterns.find(p => file.includes(p));
        if (match) matches.push({ file: fullPath, reason: match });
      });
    }
    walk(dir);
    return matches;
  }

  try {
    const files = crawlDirectory(targetPath);
    const grouped = [{
      id: 'scan-' + Date.now(),
      label: `Scan for goal: ${goal}`,
      context: `Files possibly related to ${goal}`,
      files: files.map(f => f.file)
    }];
    res.status(200).json(grouped);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}