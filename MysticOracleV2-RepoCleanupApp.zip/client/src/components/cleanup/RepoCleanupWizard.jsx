import { useState, useEffect } from 'react';

export default function RepoCleanupWizard() {
  const [stage, setStage] = useState('start');
  const [fileGroups, setFileGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [keepMap, setKeepMap] = useState({});
  const [commandInput, setCommandInput] = useState('');

  // When a user types a journey like "daily horoscope" and runs the crawler,
  // we dynamically fetch related file groups from the backend API.
  const handleCrawlCommand = async () => {
    if (!commandInput.trim()) return;
    try {
      const res = await fetch(`/api/crawler?goal=${encodeURIComponent(commandInput)}`);
      const data = await res.json();
      setFileGroups(data);
      setStage('start');
    } catch (err) {
      console.error('Failed to run crawler:', err);
    }
  };

  const startReview = (group) => {
    setSelectedGroup(group);
    setStage('review');
  };

  const toggleKeep = (file) => {
    setKeepMap(prev => ({ ...prev, [file]: !prev[file] }));
  };

  const finalizeReview = () => {
    console.log('Cleanup decision for group:', selectedGroup.id);
    console.log('Keep map:', keepMap);
    setStage('start');
    setSelectedGroup(null);
    setKeepMap({});
  };

  return (
    <div className="p-6 max-w-xl mx-auto bg-white shadow rounded">
      <h1 className="text-2xl font-bold mb-4">🧼 Repo Cleanup Wizard</h1>

      {/* Input box and button to trigger the backend file crawler */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Investigate a specific user journey:
        </label>
        <input
          type="text"
          value={commandInput}
          onChange={(e) => setCommandInput(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md"
          placeholder="e.g. daily horoscope"
        />
        <button
          onClick={handleCrawlCommand}
          className="mt-2 px-3 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700"
        >
          Run Crawler
        </button>
      </div>

      {/* Start screen: list file groups returned from the backend crawler */}
      {stage === 'start' && (
        <div>
          <p className="mb-2 text-gray-700">Select a feature or flow to review associated files:</p>
          <ul className="space-y-3">
            {fileGroups.map(group => (
              <li key={group.id} className="border p-3 rounded hover:bg-violet-50 cursor-pointer" onClick={() => startReview(group)}>
                <strong>{group.label}</strong>
                <p className="text-sm text-gray-500">{group.context}</p>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Review screen: display files and allow marking Keep/Discard */}
      {stage === 'review' && selectedGroup && (
        <div>
          <h2 className="text-xl font-semibold mb-2">Review: {selectedGroup.label}</h2>
          <p className="mb-4 text-gray-600">{selectedGroup.context}</p>
          <ul className="space-y-2">
            {selectedGroup.files.map(file => (
              <li key={file} className="flex items-center justify-between border p-2 rounded">
                <span className="text-sm font-mono text-gray-800">{file}</span>
                <button
                  onClick={() => toggleKeep(file)}
                  className={`text-xs px-3 py-1 rounded ${keepMap[file] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
                >
                  {keepMap[file] ? 'Keep' : 'Discard'}
                </button>
              </li>
            ))}
          </ul>
          <button onClick={finalizeReview} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Done with this group
          </button>
        </div>
      )}
    </div>
  );
}