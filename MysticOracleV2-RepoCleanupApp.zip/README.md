# MysticOracleV2 Repo Cleanup App

This project adds a full-stack cleanup assistant to your MysticOracleV2 repo.

## Features

- 🧼 Interactive UI to guide file deletion/retention
- 🕵️ Crawler backend to detect `-fixed`, `-updated`, or `legacy` files
- 🎯 Goal-based flow scanning (e.g. "daily horoscope")

## Setup

1. Place `client/` and `server/` into your existing MysticOracleV2 project.
2. Wire `RepoCleanupWizard.jsx` into your frontend.
3. Ensure `/api/crawler.js` is hosted locally or via Netlify/Supabase.
4. Start your dev server and visit the Cleanup Wizard page.