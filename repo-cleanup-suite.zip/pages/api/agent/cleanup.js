// API route to run RepoCleanupAgent
