// Utility for scanning files
