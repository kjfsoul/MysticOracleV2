// Utility for analyzing usage graphs
